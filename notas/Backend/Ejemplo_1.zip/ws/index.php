<?php
$f3 = require('lib/base.php');
$f3->route('GET /',
    function() {
        echo 'Hello, world!';
    }
);

$f3->route('GET /otro',
    function() {
        echo 'otro';
    }
);


$f3->run();
?>