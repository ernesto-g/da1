<?php

class ControllerDevices extends ControllerManager
{


	public function get($f3)
	{
		if($f3->get('PARAMS.id')!=null)
		{
			$id = $f3->get('PARAMS.id');
			echo("Vino un GET por id:$id");
		}
		else
		{
			echo("Vino un GET devuelvo lista. Datos:");
			print_r($_GET);
		}

	}

	public function post($f3)
	{
		echo("Vino un POST");
	}

}

?>