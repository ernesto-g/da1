<?php


class ControllerManager
{


	public function beforeRoute($f3)
        {
		echo("Ejecuto esto antes de rutear");
	}



}

?>